import javax.swing.*;

public class GUI {
    public JFrame frame;
    public JLabel calorieCounterLabel;
    public JButton goalButton;
    public JButton exerciseButton;
    public JButton stepButton;
    public JButton loseButton;
    public JButton maintainButton;
    public JButton gainButton;
    public JTextField nameField;
    public JTextField heightField;
    public JTextField weightField;
    public JTextField dateOfBirth;
    public JButton createButton;
    public JPanel panel;
    public JTextField stepsField;
    public JButton submitButton;
    public JComboBox<String> exerciseComboBox;
    public JTextField durationField;


    public JFrame returnJFrame(){
        return frame;
    }
}
